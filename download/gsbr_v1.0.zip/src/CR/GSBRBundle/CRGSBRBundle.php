<?php

namespace CR\GSBRBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CRGSBRBundle extends Bundle
{
}
