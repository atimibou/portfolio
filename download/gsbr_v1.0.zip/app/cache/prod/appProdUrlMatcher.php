<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/GSBR')) {
            // crgsbr_homepage
            if (rtrim($pathinfo, '/') === '/GSBR') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'crgsbr_homepage');
                }

                return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\DefaultController::accueilAction',  '_route' => 'crgsbr_homepage',);
            }

            // crgsbr_profil
            if ($pathinfo === '/GSBR/profil') {
                return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\DefaultController::profilAction',  '_route' => 'crgsbr_profil',);
            }

            // crgsbr_liste_medicament
            if ($pathinfo === '/GSBR/listeMedicament') {
                return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::listeMedicamentAction',  '_route' => 'crgsbr_liste_medicament',);
            }

            // crgsbr_recherche_medicament
            if ($pathinfo === '/GSBR/rechercheMedicament') {
                return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::rechercheMedicamentAction',  '_route' => 'crgsbr_recherche_medicament',);
            }

            // crgsbr_liste_praticien
            if ($pathinfo === '/GSBR/listePraticien') {
                return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::listePraticienAction',  '_route' => 'crgsbr_liste_praticien',);
            }

            // crgsbr_recherche_praticien
            if ($pathinfo === '/GSBR/recherchePraticien') {
                return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::recherchePraticienAction',  '_route' => 'crgsbr_recherche_praticien',);
            }

            // crgsbr_consulter_visite
            if ($pathinfo === '/GSBR/consulterVisite') {
                return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::consulterVisiteAction',  '_route' => 'crgsbr_consulter_visite',);
            }

            // crgsbr_ajouter_visite
            if ($pathinfo === '/GSBR/ajouterVisite') {
                return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::ajouterVisiteAction',  '_route' => 'crgsbr_ajouter_visite',);
            }

            if (0 === strpos($pathinfo, '/GSBR/connexion')) {
                // crgsbr_connexion
                if ($pathinfo === '/GSBR/connexion') {
                    return array (  '_controller' => 'CR\\GSBRBundle\\Controller\\DefaultController::connexionAction',  '_route' => 'crgsbr_connexion',);
                }

                // crgsbr_connexion_check
                if ($pathinfo === '/GSBR/connexion_check') {
                    return array('_route' => 'crgsbr_connexion_check');
                }

            }

            // crgsbr_deconnexion
            if ($pathinfo === '/GSBR/deconnexion') {
                return array('_route' => 'crgsbr_deconnexion');
            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
