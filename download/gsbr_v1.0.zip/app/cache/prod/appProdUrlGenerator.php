<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * appProdUrlGenerator
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes = array(
        'crgsbr_homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\DefaultController::accueilAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_profil' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\DefaultController::profilAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/profil',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_liste_medicament' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::listeMedicamentAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/listeMedicament',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_recherche_medicament' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::rechercheMedicamentAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/rechercheMedicament',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_liste_praticien' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::listePraticienAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/listePraticien',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_recherche_praticien' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::recherchePraticienAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/recherchePraticien',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_consulter_visite' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::consulterVisiteAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/consulterVisite',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_ajouter_visite' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\GSBRController::ajouterVisiteAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/ajouterVisite',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_connexion' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'CR\\GSBRBundle\\Controller\\DefaultController::connexionAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/connexion',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_connexion_check' => array (  0 =>   array (  ),  1 =>   array (  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/connexion_check',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'crgsbr_deconnexion' => array (  0 =>   array (  ),  1 =>   array (  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/GSBR/deconnexion',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
    );

    /**
     * Constructor.
     */
    public function __construct(RequestContext $context, LoggerInterface $logger = null)
    {
        $this->context = $context;
        $this->logger = $logger;
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
