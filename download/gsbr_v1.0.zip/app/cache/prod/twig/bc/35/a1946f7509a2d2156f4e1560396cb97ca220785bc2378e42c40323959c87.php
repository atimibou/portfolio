<?php

/* CRGSBRBundle:GSBR:recherchePraticien.html.twig */
class __TwigTemplate_bc35a1946f7509a2d2156f4e1560396cb97ca220785bc2378e42c40323959c87 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        try {
            $this->parent = $this->env->loadTemplate("CRGSBRBundle::layout.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(1);

            throw $e;
        }

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRGSBRBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        // line 3
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "
    <h2 class=\"text-center\">Chercher les praticiens</h2><hr>
    <div role=\"tabpanel\">

        <!-- Nav tabs -->
        <ul class=\"nav nav-tabs\" role=\"tablist\">
            <li role=\"menu\" class=\"active\"><a href=\"#simple\" aria-controls=\"home\" role=\"tab\" data-toggle=\"tab\">Simple</a></li>
            <li role=\"menu\"><a href=\"#avancee\" aria-controls=\"profile\" role=\"tab\" data-toggle=\"tab\">Avancée</a></li>
        </ul>

        <!-- Tab panes -->
        <div class=\"tab-content\">
            <div role=\"tabpanel\" class=\"tab-pane active\" id=\"simple\">
                <br />
                <form method=\"POST\" action=\"";
        // line 20
        echo $this->env->getExtension('routing')->getPath("crgsbr_recherche_praticien");
        echo "\" class=\"form-horizontal\">
                    <div class=\"form-group\">
                        <label class=\"col-sm-3 control-label\" for=\"Type\">Type</label>
                        <div class=\"col-sm-6\">
                            <select class=\"form-control\" id=\"Type\" name=\"idTypeMedecin\">
                                ";
        // line 25
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lesTypes"]) ? $context["lesTypes"] : $this->getContext($context, "lesTypes")));
        foreach ($context['_seq'] as $context["_key"] => $context["unTypes"]) {
            // line 26
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["unTypes"], "id", array()), "html", null, true);
            echo "\"> ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["unTypes"], "libelleType", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unTypes'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "                            </select>
                        </div>
                    </div>
                    <div class=\"text-center\">
                        <button type=\"submit\" class=\"btn btn-primary\"><span class=\"glyphicon glyphicon-search\" aria-hidden=\"true\"></span> Chercher</button>
                    </div>
                </form>
            </div>
            <div role=\"tabpanel\" class=\"tab-pane\" id=\"avancee\">
                <br />
                <form method=\"POST\" action=\"";
        // line 38
        echo $this->env->getExtension('routing')->getPath("crgsbr_recherche_praticien");
        echo "\" class=\"form-horizontal\">
                    <div class=\"form-group\">
                        <label class=\"col-sm-3 control-label\">Nom</label>
                        <div class=\"col-sm-6\">
                            <input type=\"text\" name=\"nom\" class=\"form-control\" />
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-3 control-label\">Ville</label>
                        <div class=\"col-sm-6\">
                            <input type=\"text\" name=\"ville\" class=\"form-control\" />
                        </div>
                    </div>
                    <div class=\"text-center\">
                        <button type=\"submit\" class=\"btn btn-primary\"><span class=\"glyphicon glyphicon-search\" aria-hidden=\"true\"></span> Chercher</button>
                    </div>
                </form>
            </div>
        </div>

    </div>  
    ";
        // line 59
        if ((isset($context["resultat"]) ? $context["resultat"] : $this->getContext($context, "resultat"))) {
            // line 60
            echo "
        <h2 class=\"text-center\">Voici les résultats de la recherche</h2><hr>
        <table class=\"table table-bordered table-body-center\" >
            <thead>
                <tr>
                    <th width=\"25%\">Nom</th>
                    <th width=\"25%\">Prénom</th>
                    <th width=\"25%\">Ville</th>
                    <th width=\"25%\">Type</th>
                </tr>
                ";
            // line 70
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($context["resultat"]);
            foreach ($context['_seq'] as $context["_key"] => $context["resultat"]) {
                // line 71
                echo "                    <tr>
                        <td class=\"text-primary\"> <strong> ";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute($context["resultat"], "nomMedecin", array()), "html", null, true);
                echo " </strong> </td>
                        <td> ";
                // line 73
                echo twig_escape_filter($this->env, $this->getAttribute($context["resultat"], "prenomMedecin", array()), "html", null, true);
                echo "</td>
                        <td> ";
                // line 74
                echo twig_escape_filter($this->env, $this->getAttribute($context["resultat"], "villeMedecin", array()), "html", null, true);
                echo "</td>
                        <td> ";
                // line 75
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["resultat"], "getTypeMedecin", array()), "getLibelleType", array()), "html", null, true);
                echo "</td>                    
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resultat'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 78
            echo "        </table>
    ";
        }
    }

    public function getTemplateName()
    {
        return "CRGSBRBundle:GSBR:recherchePraticien.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 78,  158 => 75,  154 => 74,  150 => 73,  146 => 72,  143 => 71,  139 => 70,  127 => 60,  125 => 59,  101 => 38,  89 => 28,  78 => 26,  74 => 25,  66 => 20,  50 => 6,  47 => 5,  40 => 3,  37 => 2,  11 => 1,);
    }
}
