<?php

/* CRGSBRBundle::layout.html.twig */
class __TwigTemplate_84c15b7eb78c79aab79a326e29cd6db8a24231e5be321fb8e33db1f5031a958f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "    </head>

    <body>

        <nav class=\"navbar navbar-inverse\">
            <div class=\"container-fluid\">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                        <span class=\"sr-only\">Toggle navigation</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                    <a class=\"navbar-brand\" href=\"";
        // line 26
        echo $this->env->getExtension('routing')->getPath("crgsbr_homepage");
        echo "\">GSBR</a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                    <ul class=\"nav navbar-nav navbar-left\">
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\">Médicaments<span class=\"caret\"></span></a>
                            <ul class=\"dropdown-menu\" role=\"menu\">
                                <li><a href=\"";
        // line 35
        echo $this->env->getExtension('routing')->getPath("crgsbr_liste_medicament");
        echo "\">Consulter</a></li>
                                <li class=\"divider\"></li>
                                <li><a href=\"";
        // line 37
        echo $this->env->getExtension('routing')->getPath("crgsbr_recherche_medicament");
        echo "\">Chercher</a></li>
                            </ul>
                        </li>
                    </ul>
                    <ul class=\"nav navbar-nav navbar-left\">
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\">Praticiens<span class=\"caret\"></span></a>
                            <ul class=\"dropdown-menu\" role=\"menu\">
                                <li><a href=\"";
        // line 45
        echo $this->env->getExtension('routing')->getPath("crgsbr_liste_praticien");
        echo "\">Consulter</a></li>
                                <li class=\"divider\"></li>
                                <li><a href=\"";
        // line 47
        echo $this->env->getExtension('routing')->getPath("crgsbr_recherche_praticien");
        echo "\">Chercher</a></li>
                            </ul>
                        </li>
                    </ul>
                    <ul class=\"nav navbar-nav navbar-left\">
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\">Visite<span class=\"caret\"></span></a>
                            <ul class=\"dropdown-menu\" role=\"menu\">
                                <li><a href=\"";
        // line 55
        echo $this->env->getExtension('routing')->getPath("crgsbr_consulter_visite");
        echo "\">Consulter</a></li>
                                <li class=\"divider\"></li>
                                <li><a href=\"";
        // line 57
        echo $this->env->getExtension('routing')->getPath("crgsbr_ajouter_visite");
        echo "\">Ajouter</a></li>
                            </ul>
                        </li>
                    </ul>
                    ";
        // line 61
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 62
            echo "                        <ul class=\"nav navbar-nav navbar-right\">
                            <li class=\"dropdown\">
                                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\">Bienvenue, ";
            // line 64
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "nom", array()) . " ") . $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "prenom", array())), "html", null, true);
            echo "<span class=\"caret\"></span></a>
                                <ul class=\"dropdown-menu\" role=\"menu\">
                                    <li><a href=\"";
            // line 66
            echo $this->env->getExtension('routing')->getPath("crgsbr_profil");
            echo "\">Profil</a></li>
                                    <li class=\"divider\"></li>
                                    <li><a href=\"";
            // line 68
            echo $this->env->getExtension('routing')->getPath("crgsbr_deconnexion");
            echo "\">Deconnexion</a></li>
                                </ul>
                            </li>
                        </ul>
                    ";
        }
        // line 73
        echo "                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>

        <div class=\"container\">
            <div class=\"row\">
                <div id=\"content\" class=\"col-md-12\">
                    ";
        // line 80
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "all", array()));
        foreach ($context['_seq'] as $context["label"] => $context["flashes"]) {
            // line 81
            echo "                        ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($context["flashes"]);
            foreach ($context['_seq'] as $context["_key"] => $context["flash"]) {
                // line 82
                echo "                            <div class=\"alert alert-";
                echo twig_escape_filter($this->env, $context["label"], "html", null, true);
                echo "\">
                                ";
                // line 83
                echo twig_escape_filter($this->env, $context["flash"], "html", null, true);
                echo "
                            </div>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 86
            echo "                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['flashes'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 87
        echo "                    ";
        $this->displayBlock('body', $context, $blocks);
        // line 89
        echo "                </div>
            </div>

            <hr>

            <footer>
                <p></p>
            </footer>
        </div>

        ";
        // line 99
        $this->displayBlock('javascripts', $context, $blocks);
        // line 103
        echo "
    </body>
</html>";
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        echo "GSBR";
    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 10
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/GSBR/css/bootstrap.css"), "html", null, true);
        echo "\">
        ";
    }

    // line 87
    public function block_body($context, array $blocks = array())
    {
        // line 88
        echo "                    ";
    }

    // line 99
    public function block_javascripts($context, array $blocks = array())
    {
        // line 100
        echo "            <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
            <script src=\"";
        // line 101
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/GSBR/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        ";
    }

    public function getTemplateName()
    {
        return "CRGSBRBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 101,  221 => 100,  218 => 99,  214 => 88,  211 => 87,  204 => 10,  201 => 9,  195 => 7,  189 => 103,  187 => 99,  175 => 89,  172 => 87,  166 => 86,  157 => 83,  152 => 82,  147 => 81,  143 => 80,  134 => 73,  126 => 68,  121 => 66,  116 => 64,  112 => 62,  110 => 61,  103 => 57,  98 => 55,  87 => 47,  82 => 45,  71 => 37,  66 => 35,  54 => 26,  38 => 12,  36 => 9,  31 => 7,  23 => 1,);
    }
}
