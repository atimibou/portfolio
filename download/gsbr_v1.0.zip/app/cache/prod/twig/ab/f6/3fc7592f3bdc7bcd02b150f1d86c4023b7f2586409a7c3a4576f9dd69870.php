<?php

/* CRGSBRBundle:GSBR:rechercheMedicament.html.twig */
class __TwigTemplate_abf63fc7592f3bdc7bcd02b150f1d86c4023b7f2586409a7c3a4576f9dd69870 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        try {
            $this->parent = $this->env->loadTemplate("CRGSBRBundle::layout.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(1);

            throw $e;
        }

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRGSBRBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        // line 3
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "
    <h2 class=\"text-center\">Chercher les médicaments</h2><hr>
    <div class=\"row highlight\">
        <form method=\"POST\" action=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("crgsbr_recherche_medicament");
        echo "\" class=\"form-horizontal\">
            <div class=\"form-group\">
                <label class=\"col-sm-3 control-label\">Famille</label>
                <div class=\"col-sm-6\">
                    <select class=\"form-control\" id=\"idFamille\" name=\"idFamille\">
                        ";
        // line 14
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lesFamilles"]) ? $context["lesFamilles"] : $this->getContext($context, "lesFamilles")));
        foreach ($context['_seq'] as $context["_key"] => $context["uneFamille"]) {
            // line 15
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["uneFamille"], "getId", array()), "html", null, true);
            echo "\"> ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["uneFamille"], "getLibelleFamille", array()), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['uneFamille'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "                    </select>
                </div>
            </div>
            <div class=\"text-center\">
                <button type=\"submit\" class=\"btn btn-primary\"><span class=\"glyphicon glyphicon-search\" aria-hidden=\"true\"></span> Chercher</button>
            </div>
        </form>
    </div>
    ";
        // line 25
        if ((isset($context["resultats"]) ? $context["resultats"] : $this->getContext($context, "resultats"))) {
            // line 26
            echo "        <h2 class=\"text-center\">Voici les résultats de la recherche</h2><hr>
        <table class=\"table table-bordered table-body-center\" >
            <thead>
                <tr>
                    <th width=\"50%\">Nom commercial</th>
                    <th width=\"50%\">Famille</th>
                </tr>
                ";
            // line 33
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["resultats"]) ? $context["resultats"] : $this->getContext($context, "resultats")));
            foreach ($context['_seq'] as $context["_key"] => $context["resultat"]) {
                // line 34
                echo "                    <tr>
                        <td style=\"color:#0099FF\">";
                // line 35
                echo twig_escape_filter($this->env, $this->getAttribute($context["resultat"], "nomCommercial", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 36
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["resultat"], "getFamille", array()), "getLibelleFamille", array()), "html", null, true);
                echo "</td>
                    </tr>  
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resultat'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 39
            echo "        </table>
    ";
        }
    }

    public function getTemplateName()
    {
        return "CRGSBRBundle:GSBR:rechercheMedicament.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 39,  110 => 36,  106 => 35,  103 => 34,  99 => 33,  90 => 26,  88 => 25,  78 => 17,  67 => 15,  63 => 14,  55 => 9,  50 => 6,  47 => 5,  40 => 3,  37 => 2,  11 => 1,);
    }
}
