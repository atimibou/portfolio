<?php

/* CRGSBRBundle:GSBR:listePraticien.html.twig */
class __TwigTemplate_898deaf328e03a1283e71a42c542d5a592d5f2cae7ffd84ed35434b3b5b1573e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        try {
            $this->parent = $this->env->loadTemplate("CRGSBRBundle::layout.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(2);

            throw $e;
        }

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRGSBRBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <h2 class=\"text-center\">Liste des Praticiens</h2><br/>
    <table class=\"table table-bordered\">
        <tr>
            <th width=\"25%\">Nom</th>
            <th width=\"25%\">Prénom</th>
            <th width=\"25%\">Ville</th>
            <th width=\"25%\">Type</th>
        </tr>
        ";
        // line 15
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lesPraticiens"]) ? $context["lesPraticiens"] : $this->getContext($context, "lesPraticiens")));
        foreach ($context['_seq'] as $context["_key"] => $context["unPraticien"]) {
            // line 16
            echo "            <tr>
                <td>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["unPraticien"], "getNomMedecin", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["unPraticien"], "getPrenomMedecin", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["unPraticien"], "getVilleMedecin", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unPraticien"], "getTypeMedecin", array()), "getLibelleType", array()), "html", null, true);
            echo "</td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unPraticien'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </table>
";
    }

    public function getTemplateName()
    {
        return "CRGSBRBundle:GSBR:listePraticien.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 23,  79 => 20,  75 => 19,  71 => 18,  67 => 17,  64 => 16,  60 => 15,  50 => 7,  47 => 6,  40 => 4,  37 => 3,  11 => 2,);
    }
}
