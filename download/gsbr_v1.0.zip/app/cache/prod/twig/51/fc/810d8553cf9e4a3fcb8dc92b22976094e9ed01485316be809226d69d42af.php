<?php

/* CRGSBRBundle:Default:index.html.twig */
class __TwigTemplate_51fc810d8553cf9e4a3fcb8dc92b22976094e9ed01485316be809226d69d42af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        try {
            $this->parent = $this->env->loadTemplate("CRGSBRBundle::layout.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(1);

            throw $e;
        }

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRGSBRBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        // line 3
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "    <div class=\"jumbotron\">
        <div class=\"row\">
            <div class=\"col-md-3\">
                <img class=\"img-thumbnail\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/GSBR/img/logo.png"), "html", null, true);
        echo "\" alt=\"Logo\">
            </div>
            <div class=\"col-md-9\">
                <h1 style=\"font-weight: 300\">GSBR</h1>
                <h3>Gestion des rapports de viste</h3>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "CRGSBRBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 9,  50 => 6,  47 => 5,  40 => 3,  37 => 2,  11 => 1,);
    }
}
