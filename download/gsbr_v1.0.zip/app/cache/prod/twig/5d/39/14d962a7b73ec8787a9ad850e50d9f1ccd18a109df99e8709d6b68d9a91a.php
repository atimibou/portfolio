<?php

/* CRGSBRBundle:GSBR:consulterVisite.html.twig */
class __TwigTemplate_5d3914d962a7b73ec8787a9ad850e50d9f1ccd18a109df99e8709d6b68d9a91a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        try {
            $this->parent = $this->env->loadTemplate("CRGSBRBundle::layout.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(1);

            throw $e;
        }

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRGSBRBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        // line 3
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "    <h3 class=\"text-center\">Vos rapport de visites</h3><br/>
    <table class=\"table table-bordered\">
        <tr>
            <th width=\"25%\">Date</th>
            <th width=\"25%\">Praticien</th>
            <th width=\"25%\">Ville</th>
            <th width=\"25%\">Motif</th>
        </tr>
        ";
        // line 14
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lesRapports"]) ? $context["lesRapports"] : $this->getContext($context, "lesRapports")));
        foreach ($context['_seq'] as $context["_key"] => $context["unRapport"]) {
            // line 15
            echo "            <tr>
                <td> ";
            // line 16
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["unRapport"], "getDateRapport", array()), "d/m/Y"), "html", null, true);
            echo " </td>
                <td> ";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unRapport"], "getMedecin", array()), "getNomPrenomMedecin", array()), "html", null, true);
            echo "</td>
                <td> ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unRapport"], "getMedecin", array()), "getVilleMedecin", array()), "html", null, true);
            echo "</td>
                <td> ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["unRapport"], "getMotif", array()), "html", null, true);
            echo "</td>                    
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unRapport'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "    </table>
";
    }

    public function getTemplateName()
    {
        return "CRGSBRBundle:GSBR:consulterVisite.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 22,  79 => 19,  75 => 18,  71 => 17,  67 => 16,  64 => 15,  60 => 14,  50 => 6,  47 => 5,  40 => 3,  37 => 2,  11 => 1,);
    }
}
