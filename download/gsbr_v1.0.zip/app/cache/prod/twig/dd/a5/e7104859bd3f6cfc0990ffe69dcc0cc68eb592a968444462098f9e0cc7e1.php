<?php

/* CRGSBRBundle:GSBR:listeMedicament.html.twig */
class __TwigTemplate_dda5e7104859bd3f6cfc0990ffe69dcc0cc68eb592a968444462098f9e0cc7e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        try {
            $this->parent = $this->env->loadTemplate("CRGSBRBundle::layout.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(1);

            throw $e;
        }

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRGSBRBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        // line 3
        echo "    Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "    <h2 class=\"text-center\">Liste des Médicaments</h2><br/>
    <table class=\"table table-bordered\">
        <tr>
            <th width=\"50%\">Nom commercial</th>
            <th width=\"50%\">Famille</th>
        </tr>
        ";
        // line 12
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lesMedicaments"]) ? $context["lesMedicaments"] : $this->getContext($context, "lesMedicaments")));
        foreach ($context['_seq'] as $context["_key"] => $context["unMedicament"]) {
            // line 13
            echo "            <tr>
                <td style=\"color:#0099FF\">";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["unMedicament"], "getNomCommercial", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["unMedicament"], "getFamille", array()), "getLibelleFamille", array()), "html", null, true);
            echo "</td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['unMedicament'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "    </table>
";
    }

    public function getTemplateName()
    {
        return "CRGSBRBundle:GSBR:listeMedicament.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 18,  69 => 15,  65 => 14,  62 => 13,  58 => 12,  50 => 6,  47 => 5,  40 => 3,  37 => 2,  11 => 1,);
    }
}
