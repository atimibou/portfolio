<?php

/* CRGSBRBundle:Default:connexion.html.twig */
class __TwigTemplate_30e5d51e071a16603134e100bd35aa2b21950682dfd9204c46f55d6fae95a7a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/GSBR/css/bootstrap.css"), "html", null, true);
        echo "\">


<div class=\"row connexion\">
    ";
        // line 5
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 6
            echo "        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "message", array()), "html", null, true);
            echo "</div>
    ";
        }
        // line 8
        echo "    <div class=\"col-sm-6 col-sm-offset-3\">
\t\t<div class=\"row\">
\t\t\t<div class=\"text-center\">
\t\t\t\t<img src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/GSBR/img/logo.png"), "html", null, true);
        echo "\" alt=\"Logo\">
\t\t\t</div>
\t\t</div>
        <form action=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("crgsbr_connexion_check");
        echo "\" method=\"post\">
            <div class=\"form-group\">
                <label for=\"username\">LOGIN</label>
                <input type=\"text\" class=\"form-control\" id=\"username\" name=\"_username\">
            </div>
            <div class=\"form-group\">
                <label for=\"password\">MOT DE PASSE</label>
                <input type=\"password\" class=\"form-control\" id=\"password\" name=\"_password\">
            </div>
\t\t\t<div class=\"text-center\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-lg btn-primary\">Connexion</button>
\t\t\t</div>
        </form>
    </div>
</div>

";
    }

    public function getTemplateName()
    {
        return "CRGSBRBundle:Default:connexion.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 14,  40 => 11,  35 => 8,  29 => 6,  27 => 5,  19 => 1,);
    }
}
